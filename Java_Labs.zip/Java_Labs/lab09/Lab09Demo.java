package practice.lab09;

import java.util.*;

public class Lab09Demo {
    enum Level { LOW, MEDIUM, HIGH }
    record Student(String name,int age) { }
    static class Book {
        final String isbn,title;Book(String isbn,String title){this.isbn=isbn;this.title=title;}
        @Override public boolean equals(Object other){return other instanceof Book b&&isbn.equals(b.isbn);}
        @Override public int hashCode(){return Objects.hash(isbn);}
        @Override public String toString(){return title+" ("+isbn+")";}
    }
    static class SimpleList<T> implements Iterable<T> {
        private static class Node<T>{final T value;Node<T> next;Node(T value){this.value=value;}}
        private Node<T> head,tail;
        void add(T value){Node<T> n=new Node<>(value);if(tail==null)head=n;else tail.next=n;tail=n;}
        public Iterator<T> iterator(){return new Iterator<>(){Node<T> current=head;public boolean hasNext(){return current!=null;}public T next(){if(!hasNext())throw new NoSuchElementException();T value=current.value;current=current.next;return value;}};}
    }
    enum Coin { PENNY(1),NICKEL(5),DIME(10),QUARTER(25);final int value;Coin(int value){this.value=value;} }
    static Map<Coin,Integer> fewestCoins(int cents){if(cents<0)throw new IllegalArgumentException("Amount must be nonnegative");Map<Coin,Integer> result=new LinkedHashMap<>();for(Coin c:new Coin[]{Coin.QUARTER,Coin.DIME,Coin.NICKEL,Coin.PENNY}){result.put(c,cents/c.value);cents%=c.value;}return result;}
    public static void main(String[] args){
        for(Level level:Level.values())System.out.println(level+": "+switch(level){case LOW->"Take your time";case MEDIUM->"Stay focused";case HIGH->"Ask for help";});
        Student a=new Student("Anesu",20),b=new Student("Anesu",20);System.out.println(a+" equal records? "+a.equals(b)+", name="+a.name());
        Set<Book> books=new HashSet<>();books.add(new Book("978-1","Java"));books.add(new Book("978-1","Duplicate edition"));System.out.println("Unique ISBNs: "+books);
        SimpleList<String> list=new SimpleList<>();list.add("first");list.add("second");for(String item:list)System.out.println(item);
        System.out.println("Change for 87 cents: "+fewestCoins(87));
    }
}
