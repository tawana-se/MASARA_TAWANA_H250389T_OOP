package practice.lab05;

import java.util.Arrays;

public class Lab05Demo {
    static class Printer {
        void print(int x) { System.out.println("int=" + x); }
        void print(double x) { System.out.println("double=" + x); }
        void print(String x) { System.out.println("text=" + x); }
        void print(int[] x) { System.out.println("array=" + Arrays.toString(x)); }
    }
    static class Animal { String sound() { return "..."; } }
    static class Cat extends Animal { @Override String sound() { return "Meow"; } }
    static class Cow extends Animal { @Override String sound() { return "Moo"; } }
    static class Duck extends Animal { @Override String sound() { return "Quack"; } }
    static class Employee { final String name; final double salary; Employee(String n, double s) { name=n; salary=s; } double pay() { return salary; } }
    static class Intern extends Employee { Intern(String n,double s) { super(n,s); } @Override double pay() { return salary * 0.8; } }
    static class Manager extends Employee { Manager(String n,double s) { super(n,s); } @Override double pay() { return salary + 250; } }
    static class Dog extends Animal { void fetch() { System.out.println("Fetching the ball"); } }
    public static void main(String[] args) {
        Printer p = new Printer(); p.print(4); p.print(3.5); p.print("hello"); p.print(new int[]{1,2});
        for (Animal a : new Animal[]{new Cat(), new Cow(), new Duck()}) System.out.println(a.sound());
        Employee[] staff = { new Employee("Base", 1000), new Intern("Intern", 800), new Manager("Lead", 1400) };
        double payroll = 0; for (Employee e : staff) { payroll += e.pay(); System.out.printf("%s %.2f%n", e.name, e.pay()); }
        System.out.printf("Payroll: %.2f%n", payroll);
        Animal animal = new Dog(); if (animal instanceof Dog dog) dog.fetch();
    }
}
