package practice.lab06;

import java.util.Arrays;
import java.util.Comparator;

public class Lab06Demo {
    abstract static class Shape { abstract double area(); abstract double perimeter(); }
    static class Circle extends Shape { final double r; Circle(double r) { this.r=r; } double area(){return Math.PI*r*r;} double perimeter(){return 2*Math.PI*r;} }
    static class Rectangle extends Shape { final double w,h; Rectangle(double w,double h){this.w=w;this.h=h;} double area(){return w*h;} double perimeter(){return 2*(w+h);} }
    static class Square extends Rectangle { Square(double side){super(side,side);} }
    interface Flyable { void fly(); default String status(){return "airborne";} }
    static class Bird implements Flyable { public void fly(){System.out.println("Bird flaps; " + status());} }
    static class Aeroplane implements Flyable { public void fly(){System.out.println("Aeroplane engines on; " + status());} }
    abstract static class Account { protected double balance; Account(double b){balance=b;} void deposit(double a){if(a<=0)throw new IllegalArgumentException("Deposit must be positive");balance+=a;} abstract double monthlyFee(); }
    static class SavingsAccount extends Account { SavingsAccount(double b){super(b);} double monthlyFee(){return 2.5;} }
    static class CurrentAccount extends Account { CurrentAccount(double b){super(b);} double monthlyFee(){return 8;} }
    record Student(String name, int marks) implements Comparable<Student> { public int compareTo(Student other){return name.compareToIgnoreCase(other.name);} }
    public static void main(String[] args) {
        Shape[] shapes={new Circle(2),new Rectangle(3,4),new Square(3)};
        for(Shape shape:shapes)System.out.printf("%s area %.2f, perimeter %.2f%n",shape.getClass().getSimpleName(),shape.area(),shape.perimeter());
        Flyable[] flyers={new Bird(),new Aeroplane()}; for(Flyable f:flyers)f.fly();
        Account[] accounts={new SavingsAccount(100),new CurrentAccount(100)};for(Account a:accounts){a.deposit(20);System.out.printf("Balance %.2f after fee %.2f%n",a.balance,a.monthlyFee());}
        Student[] students={new Student("Tariro",70),new Student("Anesu",91),new Student("Kundai",82)};
        Arrays.sort(students);System.out.println("By name: "+Arrays.toString(students));
        Arrays.sort(students,Comparator.comparingInt(Student::marks).reversed());System.out.println("By marks: "+Arrays.toString(students));
    }
}
