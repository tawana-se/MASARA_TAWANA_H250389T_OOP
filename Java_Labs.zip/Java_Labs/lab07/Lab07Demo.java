package practice.lab07;

import java.io.StringReader;
import java.util.Scanner;

public class Lab07Demo {
    static void divideInput(Scanner scanner) {
        try {
            System.out.print("Enter two integers: ");
            int a=scanner.nextInt(), b=scanner.nextInt();
            System.out.println("Result: "+(a/b));
        } catch (java.util.InputMismatchException e) { System.out.println("Please enter integers only"); scanner.nextLine(); }
        catch (ArithmeticException e) { System.out.println("Cannot divide by zero"); }
        finally { System.out.println("Division attempt finished"); }
    }
    static int at(int[] values,int index){return values[index];}
    static class InvalidAgeException extends Exception { InvalidAgeException(String message){super(message);} }
    static void validateAge(int age) throws InvalidAgeException { if(age<0||age>120)throw new InvalidAgeException("Age must be between 0 and 120"); }
    static class InsufficientFundsException extends Exception { InsufficientFundsException(double requested,double balance){super("Requested "+requested+", available "+balance);} }
    static class BankAccount {
        private double balance; BankAccount(double balance){this.balance=balance;}
        void withdraw(double amount) throws InsufficientFundsException { if(amount>balance)throw new InsufficientFundsException(amount,balance); if(amount<=0)throw new IllegalArgumentException("Amount must be positive"); balance-=amount; }
    }
    static int finallyDemo(){try{return 1;}finally{System.out.println("finally runs even when try returns");}}
    public static void main(String[] args) {
        divideInput(new Scanner(new StringReader("12 3"))); divideInput(new Scanner(new StringReader("12 0"))); divideInput(new Scanner(new StringReader("twelve 3")));
        try{System.out.println(at(new int[]{4,8},5));}catch(ArrayIndexOutOfBoundsException e){System.out.println("Index outside the array");}
        try{validateAge(145);}catch(InvalidAgeException e){System.out.println(e.getMessage());}
        try{new BankAccount(30).withdraw(50);}catch(InsufficientFundsException e){System.out.println(e.getMessage());}
        System.out.println("Returned value: "+finallyDemo());
    }
}
