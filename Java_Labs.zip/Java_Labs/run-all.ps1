$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $root
try {
$output = Join-Path $root 'out'
New-Item -ItemType Directory -Force -Path $output | Out-Null
$sources = Get-ChildItem -Path $root -Recurse -Filter '*.java' |
  Where-Object { $_.FullName -notlike "$output\*" } |
  ForEach-Object { $_.FullName }
if (-not $sources) { throw 'No Java source files found.' }
javac -encoding UTF-8 -d $output $sources
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
$mains = @(
  'practice.lab01.Lab01Demo', 'practice.lab02.Lab02Demo',
  'practice.lab03.Lab03Demo', 'practice.lab04.Lab04Demo',
  'practice.lab05.Lab05Demo', 'practice.lab06.Lab06Demo',
  'practice.lab07.Lab07Demo', 'practice.lab08.Lab08Demo',
  'practice.lab09.Lab09Demo', 'practice.lab10.Lab10Demo',
  'practice.lab11.Lab11Demo'
)
foreach ($main in $mains) {
  Write-Host "`n=== $main ==="
  if ($main -eq 'practice.lab11.Lab11Demo') {
    Write-Host 'Library menu: type q then Enter to save and finish the automated run.'
    'q' | java -cp $output $main
  } else {
    java -cp $output $main
  }
  if ($LASTEXITCODE -ne 0) { throw "Execution failed: $main" }
}
} finally {
  Pop-Location
}
