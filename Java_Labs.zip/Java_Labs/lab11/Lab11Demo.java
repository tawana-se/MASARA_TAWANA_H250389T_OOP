package practice.lab11;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Lab11Demo {
    // Singleton: one shared application configuration instance.
    static final class AppConfig {
        private static final AppConfig INSTANCE = new AppConfig();
        private final String dataFolder = Path.of("out", "library-data").toString();
        private AppConfig() { }
        static AppConfig getInstance() { return INSTANCE; }
        String dataFolder() { return dataFolder; }
    }

    // Factory: callers request a notification through its interface.
    interface Notification { void send(String message); }
    static final class EmailNotification implements Notification { public void send(String m) { System.out.println("Email: " + m); } }
    static final class SmsNotification implements Notification { public void send(String m) { System.out.println("SMS: " + m); } }
    static final class NotificationFactory {
        static Notification create(String type) {
            return switch (type.toLowerCase(Locale.ROOT)) {
                case "email" -> new EmailNotification(); case "sms" -> new SmsNotification();
                default -> throw new IllegalArgumentException("Unknown notification type: " + type);
            };
        }
    }

    // Strategy and Observer examples used by this integrated lab.
    @FunctionalInterface interface DiscountStrategy { double apply(double amount); }
    static final class Checkout { private DiscountStrategy strategy; Checkout(DiscountStrategy s) { strategy=s; } void setStrategy(DiscountStrategy s){strategy=s;} double total(double amount){return strategy.apply(amount);} }
    @FunctionalInterface interface GradeListener { void onGrade(String course, int mark); }
    static final class GradeBook {
        private final List<GradeListener> listeners=new ArrayList<>();
        void subscribe(GradeListener listener){listeners.add(listener);}
        void publish(String course,int mark){for(GradeListener listener:listeners)listener.onGrade(course,mark);}
    }

    static final class ItemNotAvailableException extends Exception { ItemNotAvailableException(String m){super(m);} }
    static final class MemberLimitExceededException extends Exception { MemberLimitExceededException(String m){super(m);} }
    interface Borrowable { void borrow(Member member) throws ItemNotAvailableException,MemberLimitExceededException; void giveBack(); }
    static abstract class LibraryItem implements Borrowable {
        private final String id,title; private boolean available=true;
        LibraryItem(String id,String title){this.id=required(id,"Item id");this.title=required(title,"Title");}
        String id(){return id;} String title(){return title;} boolean available(){return available;}
        abstract int loanPeriodDays(); abstract String type();
        void setAvailable(boolean value){available=value;}
        public void borrow(Member member)throws ItemNotAvailableException,MemberLimitExceededException{
            if(!available)throw new ItemNotAvailableException("Item is already checked out");
            if(member.loanIds().size()>=3)throw new MemberLimitExceededException("A member may borrow at most 3 items");
            available=false;member.loanIds().add(id);
        }
        public void giveBack(){available=true;}
        public String toString(){return "["+type()+"] "+id+" | "+title+" | available="+available;}
    }
    static final class Book extends LibraryItem { Book(String id,String title){super(id,title);} int loanPeriodDays(){return 14;} String type(){return "BOOK";} }
    static final class Dvd extends LibraryItem { Dvd(String id,String title){super(id,title);} int loanPeriodDays(){return 7;} String type(){return "DVD";} }
    static final class Member {
        private final String id,name; private final List<String> loanIds=new ArrayList<>();
        Member(String id,String name){this.id=required(id,"Member id");this.name=required(name,"Member name");}
        String id(){return id;}String name(){return name;}List<String> loanIds(){return loanIds;}
        public String toString(){return "Member "+id+" | "+name+" | loans="+loanIds.size();}
    }
    static final class Loan {
        private final String memberId,itemId;private final LocalDate checkout,due;
        Loan(String memberId,String itemId,LocalDate checkout,LocalDate due){this.memberId=memberId;this.itemId=itemId;this.checkout=checkout;this.due=due;}
        String memberId(){return memberId;}String itemId(){return itemId;}LocalDate due(){return due;}
        public String toString(){return itemId+" borrowed by "+memberId+" due "+due;}
    }

    static final class Library {
        private final Map<String,LibraryItem> items=new HashMap<>();
        private final Map<String,Member> members=new HashMap<>();
        private final List<Loan> loans=new ArrayList<>();
        private final Path folder=Path.of(AppConfig.getInstance().dataFolder());
        void addItem(LibraryItem item){if(items.putIfAbsent(item.id(),item)!=null)throw new IllegalArgumentException("Duplicate item id");}
        void register(Member member){if(members.putIfAbsent(member.id(),member)!=null)throw new IllegalArgumentException("Duplicate member id");}
        void borrow(String memberId,String itemId)throws ItemNotAvailableException,MemberLimitExceededException{
            Member member=Optional.ofNullable(members.get(memberId)).orElseThrow(()->new IllegalArgumentException("Member not found: "+memberId));
            LibraryItem item=Optional.ofNullable(items.get(itemId)).orElseThrow(()->new IllegalArgumentException("Item not found: "+itemId));
            item.borrow(member);LocalDate today=LocalDate.now();loans.add(new Loan(memberId,itemId,today,today.plusDays(item.loanPeriodDays())));
        }
        void giveBack(String memberId,String itemId){
            Member member=Optional.ofNullable(members.get(memberId)).orElseThrow(()->new IllegalArgumentException("Member not found"));
            LibraryItem item=Optional.ofNullable(items.get(itemId)).orElseThrow(()->new IllegalArgumentException("Item not found"));
            Loan loan=loans.stream().filter(l->l.memberId().equals(memberId)&&l.itemId().equals(itemId)).findFirst().orElseThrow(()->new IllegalArgumentException("That member has no matching loan"));
            loans.remove(loan);member.loanIds().remove(itemId);item.giveBack();
        }
        List<LibraryItem> search(String title){String q=title.toLowerCase(Locale.ROOT);return items.values().stream().filter(i->i.title().toLowerCase(Locale.ROOT).contains(q)).sorted(Comparator.comparing(LibraryItem::title)).toList();}
        List<Loan> overdue(){LocalDate today=LocalDate.now();return loans.stream().filter(l->l.due().isBefore(today)).sorted(Comparator.comparing(Loan::due)).toList();}
        Collection<LibraryItem> items(){return items.values();}Collection<Member> members(){return members.values();}

        void save()throws IOException{
            Files.createDirectories(folder);
            List<String> itemRows=items.values().stream().sorted(Comparator.comparing(LibraryItem::id)).map(i->String.join(",",i.type(),enc(i.id()),enc(i.title()),Boolean.toString(i.available()))).toList();
            List<String> memberRows=members.values().stream().sorted(Comparator.comparing(Member::id)).map(m->enc(m.id())+","+enc(m.name())).toList();
            List<String> loanRows=loans.stream().map(l->enc(l.memberId())+","+enc(l.itemId())+","+l.due()).toList();
            Files.write(folder.resolve("items.csv"),itemRows,StandardCharsets.UTF_8);Files.write(folder.resolve("members.csv"),memberRows,StandardCharsets.UTF_8);Files.write(folder.resolve("loans.csv"),loanRows,StandardCharsets.UTF_8);
        }
        void load()throws IOException{
            Files.createDirectories(folder);
            Path itemFile=folder.resolve("items.csv");if(Files.exists(itemFile))for(String row:Files.readAllLines(itemFile,StandardCharsets.UTF_8)){
                String[] p=row.split(",",-1);if(p.length!=4)continue;LibraryItem item=p[0].equals("DVD")?new Dvd(dec(p[1]),dec(p[2])):new Book(dec(p[1]),dec(p[2]));item.setAvailable(Boolean.parseBoolean(p[3]));items.put(item.id(),item);
            }
            Path memberFile=folder.resolve("members.csv");if(Files.exists(memberFile))for(String row:Files.readAllLines(memberFile,StandardCharsets.UTF_8)){String[] p=row.split(",",-1);if(p.length==2){Member m=new Member(dec(p[0]),dec(p[1]));members.put(m.id(),m);}}
            Path loanFile=folder.resolve("loans.csv");if(Files.exists(loanFile))for(String row:Files.readAllLines(loanFile,StandardCharsets.UTF_8)){
                String[] p=row.split(",",-1);if(p.length!=3)continue;Member m=members.get(dec(p[0]));LibraryItem item=items.get(dec(p[1]));if(m!=null&&item!=null){LocalDate due=LocalDate.parse(p[2]);loans.add(new Loan(m.id(),item.id(),due.minusDays(item.loanPeriodDays()),due));m.loanIds().add(item.id());item.setAvailable(false);}
            }
        }
    }
    private static String required(String value,String label){if(value==null||value.isBlank())throw new IllegalArgumentException(label+" is required");return value.trim();}
    private static String enc(String s){return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8));}
    private static String dec(String s){return new String(Base64.getUrlDecoder().decode(s),StandardCharsets.UTF_8);}

    private static void runMenu(Scanner in,Library library)throws IOException{
        boolean running=true;
        while(running){
            System.out.println("\nLibrary: A add item | M register member | B borrow | R return | O overdue | S search | L list | Q save and quit");
            System.out.print("> ");if(!in.hasNextLine())break;String command=in.nextLine().trim().toUpperCase(Locale.ROOT);
            try{switch(command){
                case "A"->{System.out.print("Type (book/dvd): ");String type=in.nextLine().trim();System.out.print("Item id: ");String id=in.nextLine();System.out.print("Title: ");String title=in.nextLine();library.addItem(type.equalsIgnoreCase("dvd")?new Dvd(id,title):new Book(id,title));System.out.println("Item added");}
                case "M"->{System.out.print("Member id: ");String id=in.nextLine();System.out.print("Name: ");String name=in.nextLine();library.register(new Member(id,name));System.out.println("Member registered");}
                case "B"->{System.out.print("Member id: ");String member=in.nextLine();System.out.print("Item id: ");String item=in.nextLine();library.borrow(member,item);System.out.println("Loan recorded");}
                case "R"->{System.out.print("Member id: ");String member=in.nextLine();System.out.print("Item id: ");String item=in.nextLine();library.giveBack(member,item);System.out.println("Item returned");}
                case "O"->library.overdue().forEach(System.out::println);
                case "S"->{System.out.print("Title contains: ");library.search(in.nextLine()).forEach(System.out::println);}
                case "L"->{library.items().stream().sorted(Comparator.comparing(LibraryItem::id)).forEach(System.out::println);library.members().stream().sorted(Comparator.comparing(Member::id)).forEach(System.out::println);}
                case "Q"->{library.save();System.out.println("Saved CSV data in "+library.folder.toAbsolutePath());running=false;}
                default->System.out.println("Choose A, M, B, R, O, S, L or Q");
            }}catch(ItemNotAvailableException|MemberLimitExceededException|IllegalArgumentException ex){System.out.println("Could not complete action: "+ex.getMessage());}
        }
    }
    public static void main(String[] args)throws IOException{
        AppConfig first=AppConfig.getInstance(),second=AppConfig.getInstance();System.out.println("Singleton shared? "+(first==second));
        NotificationFactory.create("email").send("Library service ready");NotificationFactory.create("sms").send("Library service ready");
        Checkout checkout=new Checkout(price->price);System.out.println("Regular checkout: "+checkout.total(200));checkout.setStrategy(price->price*.9);System.out.println("Student checkout: "+checkout.total(200));
        GradeBook grades=new GradeBook();grades.subscribe((course,mark)->System.out.println("Portal: "+course+" = "+mark));grades.subscribe((course,mark)->{if(mark<50)System.out.println("Advisor alert: "+course+" needs support");});grades.publish("OOP",72);grades.publish("Databases",45);
        Library library=new Library();library.load();runMenu(new Scanner(System.in),library);
    }
}
