package practice.lab10;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Lab10Demo {
    record Student(String name,int mark){String grade(){return mark>=80?"A":mark>=60?"B":"C";}}
    static Path dataDir(){return Path.of("out","lab10-data");}
    public static void main(String[] args) throws IOException {
        Files.createDirectories(dataDir());
        Path notes=dataDir().resolve("notes.txt");List<String> five=List.of("OOP practice line 1","OOP practice line 2","OOP practice line 3","OOP practice line 4","OOP practice line 5");
        Files.write(notes,five);System.out.println("Saved and read back:");Files.readAllLines(notes).forEach(System.out::println);
        List<Integer> numbers=new ArrayList<>(List.of(1,2,3,4,5,6,7,8));Predicate<Integer> even=n->n%2==0;numbers.removeIf(even);System.out.println("Odd values after removeIf: "+numbers);
        List<String> lines=Files.readAllLines(notes);long words=lines.stream().flatMap(line->Arrays.stream(line.split("\\s+"))).count();long chars=lines.stream().mapToLong(String::length).sum();
        System.out.printf("File has %d lines, %d words, %d characters%n",lines.size(),words,chars);
        List<Student> students=List.of(new Student("Rudo",72),new Student("Anesu",90),new Student("Tariro",88),new Student("Kundai",50));
        double average=students.stream().mapToInt(Student::mark).average().orElse(0);System.out.printf("Above average (%.1f):%n",average);
        students.stream().filter(s->s.mark()>average).map(Student::name).sorted().forEach(System.out::println);
        Path csv=dataDir().resolve("learners.csv");Files.write(csv,List.of("name,mark","Anesu,90","Kundai,50","Rudo,72","Tariro,88"));
        Map<String,List<Student>> byGrade=Files.readAllLines(csv).stream().skip(1).map(row->row.split(",")).map(p->new Student(p[0],Integer.parseInt(p[1])))
            .collect(Collectors.groupingBy(Student::grade,TreeMap::new,Collectors.toList()));
        for(var entry:byGrade.entrySet()){Path report=dataDir().resolve("grade-"+entry.getKey()+".txt");Files.write(report,entry.getValue().stream().map(Student::toString).toList());System.out.println("Wrote "+report);}
    }
}
