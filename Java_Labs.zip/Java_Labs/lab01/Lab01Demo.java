package practice.lab01;

import java.util.Objects;

public class Lab01Demo {
    static class Car {
        String brand; int year; double mileage;
        Car(String brand, int year, double mileage) { this.brand = brand; this.year = year; this.mileage = mileage; }
        void display() { System.out.printf("%s %d, %.0f km, antique: %s%n", brand, year, mileage, isAntique()); }
        boolean isAntique() { return 2026 - year > 25; }
    }
    static class Rectangle {
        double width, height;
        Rectangle(double width, double height) { this.width = width; this.height = height; }
        double area() { return width * height; }
        double perimeter() { return 2 * (width + height); }
    }
    record Address(String city) { }
    static class Person { String name; Address address; Person(String name, Address address) { this.name = name; this.address = address; } }

    public static void main(String[] args) {
        System.out.println("Cars:");
        new Car("Toyota", 2018, 50_000).display();
        new Car("Mazda", 1998, 120_000).display();
        new Car("Nissan", 2005, 95_000).display();

        Rectangle[] boxes = { new Rectangle(2, 5), new Rectangle(4, 4), new Rectangle(8, 3), new Rectangle(1, 9), new Rectangle(6, 6) };
        Rectangle largest = boxes[0];
        for (Rectangle r : boxes) if (r.area() > largest.area()) largest = r;
        System.out.printf("Largest rectangle area %.1f, perimeter %.1f%n", largest.area(), largest.perimeter());
        Rectangle r1 = new Rectangle(3, 7); Rectangle r2 = r1; r2.width = 10;
        System.out.println("Aliasing changed r1.width to " + r1.width + ": " + (r1 == r2));

        Person person = new Person("Rudo", new Address("Harare"));
        System.out.println(person.name + " lives in " + person.address.city());
        Person noAddress = new Person("Tariro", null);
        System.out.println("Address present: " + Objects.nonNull(noAddress.address));
        try { System.out.println(noAddress.address.city()); }
        catch (NullPointerException expected) { System.out.println("Reading a null address would throw NullPointerException"); }
    }
}
