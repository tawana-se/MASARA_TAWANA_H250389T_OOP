# Executable OOP Java Practice Labs

This folder is a separate solution and practice set built from the exercises in **Object-Oriented Programming in Java — University Lab Manual**. It does not change the original `Lab01`–`Lab11` folders. Each lab has a task summary and a runnable `main` method. The examples combine related Basic, Intermediate and Challenge questions into one demo where practical.

## Requirements and run instructions

Use JDK 17 or newer. Open PowerShell in this folder and run:

```powershell
./run-all.ps1
```

The script compiles every source file and runs each lab. Compiled classes and Lab 10/11 data go into `out`. To run one after compilation, use `java -cp out practice.lab01.Lab01Demo` (replace the class name as needed).

## Included exercises

| Lab | Exercises demonstrated | Main class |
|---|---|---|
| 01 | Cars and antique test; rectangle area/perimeter and maximum; aliasing; person/address references and null handling | `practice.lab01.Lab01Demo` |
| 02 | Circle constructors and count; employee constructor overloads/copy; initialization order; temperature factories | `practice.lab02.Lab02Demo` |
| 03 | Validated student marks and computed grade; bank transaction history; immutable person; Kelvin temperature | `practice.lab03.Lab03Demo` |
| 04 | Person, Student and Teacher; Vehicle/Car/ElectricCar constructor order; composition-based stack | `practice.lab04.Lab04Demo` |
| 05 | Overloaded printing; animal dynamic dispatch; mixed employee payroll; safe pattern matching | `practice.lab05.Lab05Demo` |
| 06 | Abstract shapes; Flyable interface; account subclasses; Comparable and Comparator | `practice.lab06.Lab06Demo` |
| 07 | Division errors; array bounds; checked age exception; insufficient-funds exception; `finally` behavior | `practice.lab07.Lab07Demo` |
| 08 | List sum/max/reverse; Set de-duplication; generic stack; word counts; generic bubble sort | `practice.lab08.Lab08Demo` |
| 09 | Level enum; Student record; Book equality in HashSet; iterable linked list; coin change | `practice.lab09.Lab09Demo` |
| 10 | File write/read; Predicate and removeIf; file counts; streams and class average; CSV grade reports | `practice.lab10.Lab10Demo` |
| 11 | Singleton, Factory, Strategy and Observer examples; persistent menu-driven library project | `practice.lab11.Lab11Demo` |

Lab 10 creates sample inputs and reports under `out/lab10-data`. Lab 11 stores library CSV files under `out/library-data`; its menu accepts `q` to save and exit. These locations keep generated data separate from your original labs.
