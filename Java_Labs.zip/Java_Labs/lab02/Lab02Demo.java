package practice.lab02;

public class Lab02Demo {
    static class Circle {
        private static int count;
        private final double radius;
        Circle() { this(1.0); }
        Circle(double radius) { if (radius <= 0) throw new IllegalArgumentException("Radius must be positive"); this.radius = radius; count++; }
        double area() { return Math.PI * radius * radius; }
        static int getCount() { return count; }
    }
    static class Employee {
        private static int nextId = 100;
        final int id; final String name; final double salary;
        Employee(String name) { this(name, 0); }
        Employee(String name, double salary) { this(nextId++, name, salary); }
        Employee(Employee other) { this(nextId++, other.name, other.salary); }
        private Employee(int id, String name, double salary) { this.id = id; this.name = name; this.salary = salary; }
        public String toString() { return id + ": " + name + " ($" + salary + ")"; }
    }
    static class InitOrder {
        static { System.out.println("static block 1"); }
        static { System.out.println("static block 2"); }
        { System.out.println("instance block 1"); }
        { System.out.println("instance block 2"); }
        InitOrder() { System.out.println("constructor"); }
    }
    static class Temperature {
        private final double celsius;
        private Temperature(double celsius) { if (celsius < -273.15) throw new IllegalArgumentException("Below absolute zero"); this.celsius = celsius; }
        static Temperature fromCelsius(double c) { return new Temperature(c); }
        static Temperature fromFahrenheit(double f) { return new Temperature((f - 32) * 5 / 9); }
        double celsius() { return celsius; }
    }
    public static void main(String[] args) {
        System.out.printf("Circle areas: %.2f, %.2f%n", new Circle().area(), new Circle(2).area());
        System.out.println("Circles created: " + Circle.getCount());
        Employee first = new Employee("Anesu", 900); System.out.println(first); System.out.println("Copy: " + new Employee(first));
        new InitOrder();
        System.out.printf("25 C = %.1f C; 77 F = %.1f C%n", Temperature.fromCelsius(25).celsius(), Temperature.fromFahrenheit(77).celsius());
    }
}
