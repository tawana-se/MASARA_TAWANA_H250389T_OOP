package practice.lab04;

import java.util.ArrayList;
import java.util.List;

public class Lab04Demo {
    static class Person {
        protected final String name; protected final int age;
        Person(String name, int age) { this.name = name; this.age = age; System.out.println("Person constructor"); }
        void display() { System.out.println(name + ", age " + age); }
    }
    static class Student extends Person {
        private final String course;
        Student(String name, int age, String course) { super(name, age); this.course = course; System.out.println("Student constructor"); }
        @Override void display() { super.display(); System.out.println("Course: " + course); }
    }
    static class Teacher extends Person { Teacher(String name, int age) { super(name, age); } }
    static class Vehicle { Vehicle(String model) { System.out.println("Vehicle: " + model); } }
    static class Car extends Vehicle { Car(String model) { super(model); System.out.println("Car setup"); } }
    static class ElectricCar extends Car { ElectricCar(String model) { super(model); System.out.println("Electric battery setup"); } }
    static class Stack<T> {
        private final List<T> values = new ArrayList<>();
        void push(T item) { values.add(item); }
        T pop() { if (values.isEmpty()) throw new IllegalStateException("Empty stack"); return values.remove(values.size() - 1); }
        int size() { return values.size(); }
    }
    public static void main(String[] args) {
        Student s = new Student("Kundai", 19, "Computer Science"); s.display(); new Teacher("Munashe", 34).display();
        System.out.println("Multilevel constructor order:"); new ElectricCar("E-Hatch");
        Stack<String> stack = new Stack<>(); stack.push("first"); stack.push("second"); System.out.println("Popped " + stack.pop() + "; remaining " + stack.size());
    }
}
