package practice.lab03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Lab03Demo {
    static class Student {
        private final String name; private int marks;
        Student(String name, int marks) { this.name = name; setMarks(marks); }
        void setMarks(int marks) { if (marks < 0 || marks > 100) throw new IllegalArgumentException("Marks must be 0 to 100"); this.marks = marks; }
        String getGrade() { return marks >= 80 ? "A" : marks >= 65 ? "B" : marks >= 50 ? "C" : "F"; }
        public String toString() { return name + ": " + marks + " (" + getGrade() + ")"; }
    }
    static class BankAccount {
        private final String owner; private double balance; private final List<String> history = new ArrayList<>();
        BankAccount(String owner, double balance) { if (balance < 0) throw new IllegalArgumentException("Negative opening balance"); this.owner = owner; this.balance = balance; }
        void deposit(double amount) { if (amount <= 0) throw new IllegalArgumentException("Amount must be positive"); balance += amount; history.add("Deposit " + amount); }
        List<String> history() { return Collections.unmodifiableList(new ArrayList<>(history)); }
        public String toString() { return owner + " balance=" + balance; }
    }
    static final class ImmutablePerson {
        private final String name; private final int age;
        ImmutablePerson(String name, int age) { this.name = name; this.age = age; }
        String name() { return name; } int age() { return age; }
    }
    static class Temperature {
        private final double kelvin;
        Temperature(double kelvin) { if (kelvin < 0) throw new IllegalArgumentException("Below absolute zero"); this.kelvin = kelvin; }
        double celsius() { return kelvin - 273.15; } double fahrenheit() { return celsius() * 9 / 5 + 32; }
    }
    public static void main(String[] args) {
        Student student = new Student("Nyasha", 86); System.out.println(student);
        try { student.setMarks(140); } catch (IllegalArgumentException e) { System.out.println("Rejected marks: " + e.getMessage()); }
        BankAccount account = new BankAccount("Farai", 50); account.deposit(25); System.out.println(account + " | " + account.history());
        try { account.history().add("tamper"); } catch (UnsupportedOperationException e) { System.out.println("History is read-only"); }
        ImmutablePerson person = new ImmutablePerson("Rudo", 20); System.out.println(person.name() + ", age " + person.age());
        Temperature temp = new Temperature(300); System.out.printf("300 K = %.2f C = %.2f F%n", temp.celsius(), temp.fahrenheit());
    }
}
