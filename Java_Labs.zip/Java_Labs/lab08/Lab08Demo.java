package practice.lab08;

import java.util.*;
import java.util.stream.Collectors;

public class Lab08Demo {
    static class Stack<T> {
        private final List<T> data=new ArrayList<>();
        void push(T value){data.add(value);} boolean isEmpty(){return data.isEmpty();}
        T peek(){if(isEmpty())throw new EmptyStackException();return data.get(data.size()-1);}
        T pop(){T value=peek();data.remove(data.size()-1);return value;}
    }
    static <T extends Comparable<T>> void bubbleSort(T[] values){
        for(int end=values.length-1;end>0;end--)for(int i=0;i<end;i++)if(values[i].compareTo(values[i+1])>0){T t=values[i];values[i]=values[i+1];values[i+1]=t;}
    }
    static Map<String,Long> wordFrequencies(String text){
        return Arrays.stream(text.toLowerCase(Locale.ROOT).split("[^\\p{L}\\p{N}]+"))
            .filter(word->!word.isBlank()).collect(Collectors.groupingBy(w->w,Collectors.counting()));
    }
    public static void main(String[] args){
        List<Integer> nums=new ArrayList<>(List.of(4,8,1,9,2,6,3,7,5,10));
        System.out.println("Sum="+nums.stream().mapToInt(Integer::intValue).sum()+", max="+Collections.max(nums));
        List<Integer> reverse=new ArrayList<>(nums);Collections.reverse(reverse);System.out.println("Reverse="+reverse);
        System.out.println("Unique names="+new LinkedHashSet<>(List.of("Rudo","Tariro","Rudo","Anesu")));
        Stack<String> stack=new Stack<>();stack.push("one");stack.push("two");System.out.println("peek="+stack.peek()+", pop="+stack.pop());
        Map<String,Long> frequencies=wordFrequencies("Java is fun; Java is useful, and fun.");
        frequencies.entrySet().stream().sorted(Map.Entry.<String,Long>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey())).forEach(System.out::println);
        Integer[] ints={5,1,4,2};String[] words={"pear","apple","plum"};bubbleSort(ints);bubbleSort(words);
        System.out.println("Sorted integers="+Arrays.toString(ints));System.out.println("Sorted words="+Arrays.toString(words));
    }
}
